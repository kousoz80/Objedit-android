 import java.io.*;
 import java.net.*;
 import java.util.*;

class Starter{
  public static void main( String args[] ){
    Replace ap = new Replace();
    ap.ARGS = args;
    ap.Start();
  }
}
class Replace{
 String[] ARGS;

public void Start(){
_O0_in();
}
private void _O0_in(){
if( ARGS.length !=4 ){
 System.out.println("ARGUMENTS MUST BE 3\n(prev-str after-str infile outfile)\n");
 System.exit(0);
}
String str;
try{
BufferedReader din = new BufferedReader( new FileReader(ARGS[2]) );
BufferedWriter dout = new BufferedWriter( new FileWriter(ARGS[3]) );
while( (str=din.readLine()) != null ){
  if( str.indexOf(ARGS[0]) < 0 ) dout.write(str+"\n");
  else  dout.write(str.replaceAll( ARGS[0], ARGS[1])+"\n");
}
din.close();
dout.close();
Process p = Runtime.getRuntime().exec("chmod 777 "+ARGS[3]);
} catch( Exception e ){
System.out.print(""+e);
}

}
Replace( ){

}
}
